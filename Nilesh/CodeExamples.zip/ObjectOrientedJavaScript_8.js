var myArray = [];

console.log(myArray, myArray.length);

myArray[14] = 'This is Sparta';
console.log(myArray, myArray.length);
console.log(myArray[4]);

myArray['title'] =  '300';
console.log(myArray, myArray.length);


myArray[24] = 'I am Batman';
console.log(myArray, myArray.length);
