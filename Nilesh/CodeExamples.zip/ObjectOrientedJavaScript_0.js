console.log(typeof 12);
console.log(typeof 'The Name');
console.log(typeof false);
console.log(typeof {});

console.log(typeof null);
console.log(typeof undefined);

console.log(typeof []);

var theFunction = function(){
	var count = 9;
};
console.log(typeof theFunction);

console.log(typeof /[a-z]+/);

var newOne;
console.log(newOne);
newOne = null;
console.log(newOne);
